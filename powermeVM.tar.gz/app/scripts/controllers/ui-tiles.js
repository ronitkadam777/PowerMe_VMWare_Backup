'use strict';

/**
 * @ngdoc function
 * @name powermeApp.controller:UitilesCtrl
 * @description
 * # UitilesCtrl
 * Controller of the powermeApp
 */
angular.module('powermeApp')
  .controller('TilesCtrl', function ($scope) {
    $scope.page = {
      title: 'Tiles',
      subtitle: 'Place subtitle here...'
    };
  });
