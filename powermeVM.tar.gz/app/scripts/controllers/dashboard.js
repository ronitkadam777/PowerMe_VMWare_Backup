/**
 * @ngdoc function
 * @name powermeApp.controller:DashboardCtrl
 * @description # DashboardCtrl Controller of the powermeApp
 */
angular
    .module('powermeApp')
    .controller(
        'DashboardCtrl',
        function($scope, $http, $rootScope, $moment,
            averageRankingService) {
            $scope.page = {
                title: 'Dashboard',
                subtitle: 'Place subtitle here...'
            };

            $scope.options = {

                filterCriteria: "",
                systemCriteria: "",
                ChartSelector: ""
            };
            
             

            //------------------------CARD 1--------------------------------------------------------
            $rootScope.query = { "size":10000,"fields" : ["applications/sites.group.dashboard_group_name"]};
            var data = averageRankingService(environment.apiUri+'/powerme/systems/_search');
            data = JSON.parse(data);
            var Dashboard_Group_Count_Card = 0;
            var Dashboard_Group_Names = [];
            for(var i=0; i<data.hits.hits.length;i++){
            	var Test_Name = data.hits.hits[i].fields['applications/sites.group.dashboard_group_name'][0];
            	if((Dashboard_Group_Names.indexOf(Test_Name))=== -1){
            		Dashboard_Group_Names.push(Test_Name);
            	}else{
            		continue;
            	}
            }

            $rootScope.SubjectAreaCount = Dashboard_Group_Names.length;

            //---------------------CARD 2------------------------------------------------------------------
            $rootScope.query = {"size":0,"aggs":{"agg1": {"terms": {"field": "applications/sites.application/site_id","size":0}}}};

            var data = averageRankingService(environment.apiUri+'/powerme/systems/_search');

            data = JSON.parse(data);
            $rootScope.applicationCount = data.aggregations.agg1.buckets.length;
            $rootScope.Colors = ["#006990","#89CBDF","#23527C","#6DB33F","#C2CD23","#3A7C2C","#8E9191"];
            $rootScope.ApplicationNames = [];
            for(var i=0; i<data.aggregations.agg1.buckets.length; i++){
            	$rootScope.ApplicationNames[i] = data.aggregations.agg1.buckets[i].key;
            }

            //console.log(Color_Map);



            //-------------------CARD 3-------------------------------------------------------------------
            $rootScope.query = {"size":0,"aggs":{"agg1": {"terms": {"field": "applications/sites.application/site_id","size":0}}}};

            var data = averageRankingService(environment.apiUri+'/powerme/systems/_search');

            data = JSON.parse(data);
            var Dashboard_Count_Card = 0;
            for(var i=0; i<data.aggregations.agg1.buckets.length; i++){
            	Dashboard_Count_Card += data.aggregations.agg1.buckets[i].doc_count;
            }
            $rootScope.dashboardCount = Dashboard_Count_Card;

            //--------------------CARD 4----------------------------------------------------------------------
          //  $rootScope.query = { "size":10000,"query": {"bool": {"must": [{"match": {"system_name": "OBIEE"}}]}},"fields" : ["applications/sites.group.dashboards.dashboard_pages.reports.report_name"]}
            $rootScope.query = { "size":10000,"fields" : ["applications/sites.group.dashboards.dashboard_pages.reports.report_name"]}
            var resultdata = averageRankingService(environment.apiUri+'/powerme/systems/_search');
            //console.log(JSON.stringify(data));
            resultdata = JSON.parse(resultdata);
            //console.log(data);
            var Report_Count_Card = 0;

            for(var i=0; i<= resultdata.hits.hits.length; i++){
            	  if(resultdata.hits.hits[i]!=undefined){
            		  if(resultdata.hits.hits[i].fields!=undefined){
                  		Report_Count_Card += resultdata.hits.hits[i].fields["applications/sites.group.dashboards.dashboard_pages.reports.report_name"].length;
                  	}
            	  }
            }
            $rootScope.reportCount = Report_Count_Card;



            $rootScope.Filter = "";
            $rootScope.CalenderFilter = "";

            $scope.getUsers = function() {
                $scope.data = [];
                var url = 'http://www.filltext.com/?rows=10&fname={firstName}&lname={lastName}&delay=3&callback=JSON_CALLBACK';

                $http.jsonp(url).success(function(data) {
                    $scope.data = data;
                });
            };
            $scope.isApplications = false;
            $scope.isApps = false;
            $scope.getUsers();
            $http
                .post(
                    environment.apiUri+'/powerme/systems/_search', {
                        "size": 12000,
                        "fields": [
                            "system_name",
                            "applications/sites.application/site_id",
                            "applications/sites.group.dashboard_group_name",
                            "applications/sites.group.dashboards.dashboard_name"
                        ]
                    })
                .success(
                    function(data) {
                        var set = new StringSet();
                        var jsonData = new StringSet();
                        var jsonFormation = "";

                        for (var i = 0; i < data.hits.hits.length; i++) {
                            if (data.hits.hits[i].fields != undefined) {

                                set.add(data.hits.hits[i].fields["system_name"][0]); }

                        }

                        jsonFormation += '{'; // Opening Scope

                        var sysLength = set.values().length;

                        for (var i = 0; i < sysLength; i++) {
                            jsonFormation += '"' + set.values()[i] + '":[ {';
                            jsonData.values == 0;
                            jsonData = new StringSet();
                            // console.log(jsonData.values());
                            for (var j = 0; j < data.hits.hits.length; j++) {
                                if (data.hits.hits[j].fields != undefined) {
                                    if (data.hits.hits[j].fields["system_name"][0] == set
                                        .values()[i]) // Compares
                                    // all
                                    // System
                                    // with
                                    // set
                                    // iteratively
                                    {
                                        jsonData
                                            .add(data.hits.hits[j].fields["applications/sites.application/site_id"][0]); // On
                                        // match,
                                        // adds
                                        // Department
                                        // per
                                        // System

                                    }
                                }

                            }

                            var depLength = jsonData.values().length;

                            for (var j = 0; j < depLength; j++) {
                                jsonFormation += '"' + jsonData.values()[j] + '":[ {';
                                var subjectSet = new StringSet();

                                for (var k = 0; k < data.hits.hits.length; k++) {
                                    if (data.hits.hits[k].fields != undefined) {

                                        if (data.hits.hits[k].fields["applications/sites.application/site_id"][0] == jsonData
                                            .values()[j] && data.hits.hits[k].fields["system_name"][0] == set
                                            .values()[i]) // Departments
                                        // match
                                        {

                                            subjectSet
                                                .add(data.hits.hits[k].fields["applications/sites.group.dashboard_group_name"][0]); // Add
                                            // subjectAreas

                                        }
                                    }

                                }

                                var subjLength = subjectSet
                                    .values().length;
                                for (var k = 0; k < subjLength; k++) {
                                    jsonFormation += '"' + subjectSet
                                        .values()[k] + '":[';
                                    var dashBoard = new StringSet();

                                    for (var m = 0; m < data.hits.hits.length; m++) {
                                        if (data.hits.hits[m].fields != undefined) {

                                            if ((data.hits.hits[m].fields["applications/sites.group.dashboard_group_name"][0] == subjectSet
                                                    .values()[k]) && (data.hits.hits[m].fields["applications/sites.application/site_id"][0] == jsonData
                                                    .values()[j])) // &&
                                            // (data.hits.hits[m].fields.system==set.values()[i]))
                                            {

                                                dashBoard
                                                    .add(data.hits.hits[m].fields["applications/sites.group.dashboards.dashboard_name"][0]
                                                        .replace(
                                                            "=\"",
                                                            "")
                                                        .replace(
                                                            "\"",
                                                            ""));
                                            }
                                        }

                                    }

                                    var dashLength = dashBoard
                                        .values().length;
                                    for (var n = 0; n < dashLength; n++) {
                                        jsonFormation += '"' + dashBoard
                                            .values()[n] + '"';

                                        if (n != (dashLength - 1))
                                            jsonFormation += ',';
                                    }

                                    jsonFormation += "]";
                                    if (k != (subjLength - 1))
                                        jsonFormation += ',';
                                }

                                jsonFormation += '}]';
                                if (j != (depLength - 1))
                                    jsonFormation += ',';
                            }

                            jsonFormation += '}]';
                            if (i != (sysLength - 1))
                                jsonFormation += ',';

                        }

                        jsonFormation += '}';

                        // console.log(jsonFormation);
                        $scope.localCache = JSON
                            .parse(jsonFormation);
                        $rootScope.cache = $scope.localCache;

                    }).error(function() {
                    console.log("error");
                });
            var StringSet = function() {
                var setObj = {},
                    val = {};

                this.add = function(str) {
                    setObj[str] = val;
                };

                this.contains = function(str) {
                    return setObj[str] === val;
                };

                this.remove = function(str) {
                    delete setObj[str];
                };

                this.values = function() {
                    var values = [];
                    for (var i in setObj) {
                        if (setObj[i] === val) {
                            values.push(i);
                        }
                    }
                    return values;
                };
            }

            $scope.getFilterTypes = function() {
                //						console.log("Filter Types : ", $scope.options);
                $scope.graphCriteria = {};
                $scope.filterInfo = [];
                $scope.isApps = false;
                if ($scope.options.filterCriteria == "System") {
                    $scope.isApplications = false;
                    for (var key in $scope.localCache) {
                        $scope.filterInfo.push(key);
                    }

                } else if ($scope.options.filterCriteria == "Departments") {
                    $scope.isApplications = false;
                    $scope.filterInfo = [];
                    for (var key in $scope.localCache) {

                        for (var i = 0; i < $scope.localCache[key].length; i++) {

                            for (var k in $scope.localCache[key][i]) {

                                $scope.filterInfo.push(k);
                            }

                        }
                    }

                } else if ($scope.options.filterCriteria == "Applications") {
                    $scope.isApplications = true;
                    $scope.filterInfo = [];
                    for (var key in $scope.localCache) {

                        for (var i = 0; i < $scope.localCache[key].length; i++) {

                            for (var k in $scope.localCache[key][i]) {

                                for (var j = 0; j < $scope.localCache[key][i][k].length; j++) {
                                    $scope.filterInfo
                                        .push($scope.localCache[key][i][k][j]);
                                }
                            }

                        }
                    }

                }
            };

            //---------------------------CALENDER FILTER GRAPHS ----------------------------------------------
            //---------------------------CALENDER FILTER GRAPHS ----------------------------------------------
            //---------------------------CALENDER FILTER GRAPHS ----------------------------------------------

            $rootScope.getDates = function(sd, ed, label) {
                $rootScope.CalenderFilter = sd + "/" + ed + "/" + label;
                console.log($rootScope.CalenderFilter);

                var dashboard_name_calender = [];
                var dashboard_count_calender = [];
                var user_name_calender = [];
                var user_count_calender = [];
                var dashBoardDaily_Calender = [];
                var unique_name_calender = [];
                var unique_count_calender = [];


                	var res = label.split("-");
                    var year = res[1];

                    if(label == "Custom Range"){
                    	res[0] = "Custom Date",
                    	res[1] = "";
                    }
                    var start_date = moment(sd,"DD-MMM-YYYY").format("YYYY-MM-DD");
                    var end_date = moment(ed,"DD-MMM-YYYY").format("YYYY-MM-DD");


                    //Top 10 Dashboard - Calender Filter

                    $rootScope.query = {"size": 0,"query": {"bool": {"must": [{"range": {"date": {"gte": start_date}}},{"range": {"date": {"lte": end_date}}}],"must_not": [{"terms": {"_dbname": ["NA","","Welcome","1. Welcome","SSI-IB"]}}]}},"aggs": {"dashboard_names": {"terms": {"field": "repositories.applications.subject-areas.dashboards._dbname","order": {"result.value": "desc"},"size": 10},"aggs": {"result": {"sum": {"field": "repositories.applications.subject-areas.dashboards._dbcount"}}}}}};
                    var data = averageRankingService(environment.apiUri+'/powerme/statistics/_search');
                    data = JSON.parse(data);

                    for (var i = 0; i < data.aggregations.dashboard_names.buckets.length; i++) {
                            dashboard_name_calender.push(data.aggregations.dashboard_names.buckets[i].key);
                            dashboard_count_calender.push(data.aggregations.dashboard_names.buckets[i].result.value);
                        }

                    angular
                        .element('#container')
                        .highcharts({
                            chart: {
                                type: 'column'
                            },
                            legend: {
                                enabled: false
                            },
                            title: {
                                text: 'Top 10 Dashboards by Number of Hits for '+res[0]+" "+res[1]
                            },

                            xAxis: {
                                categories: dashboard_name_calender,
                                crosshair: true,
                                labels: {
                                    autoRotation: false
                                }

                            },
                            yAxis: {
                                min: 0,
                                allowDecimals: false,
                                title: {
                                    text: '# of Dashboard Hits'
                                }
                            },
                            tooltip: {
                                headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                                pointFormat: '<tr><td style="color:{series.color};padding:0">Dashboard Hits: </td>' + '<td style="padding:0"><b>{point.y:.0f}</b></td></tr>',
                                footerFormat: '</table>',
                                shared: true,
                                useHTML: true
                            },
                            plotOptions: {
                                column: {
                                    pointPadding: 0.2,
                                    borderWidth: 0
                                }
                            },
                            series: [{
                                name: 'Dashboards',
                                data: dashboard_count_calender

                            }]
                        });

                    // Code for Top 10 Users on Calender Filter

                    $rootScope.query = {"size": 0,"query": {"bool": {"must": [{"range": {"date": {"gte": start_date}}}, {"range": {"date": {"lte": end_date}}}],"must_not": [{"terms": {"_name": ["weblogic","tableauadmin"]}}]}},"aggs": {"dashboard_names": {"terms": {"field": "repositories.applications.subject-areas.dashboards.users._name","order": {"result.value": "desc"},"size": 10},"aggs": {"result": {"sum": {"field": "repositories.applications.subject-areas.dashboards.users._count"}}}}}};
                    var data = averageRankingService(environment.apiUri+'/powerme/statistics/_search');
                    data = JSON.parse(data);

                    for (var i = 0; i < data.aggregations.dashboard_names.buckets.length; i++)

                    {
                    	user_name_calender.push(data.aggregations.dashboard_names.buckets[i].key);
                        user_count_calender.push(data.aggregations.dashboard_names.buckets[i].result.value);
                    }

                    angular
                        .element('#userChart')
                        .highcharts({

                            chart: {
                                type: 'column'
                            },
                            legend: {
                                enabled: false
                            },
                            title: {
                                text: 'Top 10 Users for '+res[0]+" "+res[1]
                            },

                            xAxis: {
                                categories: user_name_calender,
                                crosshair: true,
                                labels: {
                                    autoRotation: false
                                }
                            },
                            yAxis: {
                                min: 0,
                                allowDecimals: false,
                                title: {
                                    text: '# of Dashboard Hits'
                                }
                            },
                            tooltip: {
                                headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                                pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' + '<td style="padding:0"><b>{point.y:.0f}</b></td></tr>',
                                footerFormat: '</table>',
                                shared: true,
                                useHTML: true
                            },
                            plotOptions: {
                                column: {
                                    pointPadding: 0.2,
                                    borderWidth: 0
                                }
                            },
                            series: [{
                                name: 'Users',
                                data: user_count_calender

                            }]

                        });

                    // Code for Top Weekly Dashboards on Calender Filter

                    $rootScope.query = {"size": 0,"query": {"bool": {"must": [{"range": {"date": {"gte": start_date}}},{"range": {"date": {"lte": end_date}}}]}},"aggs": {"group_by_dbname": {"date_histogram": {"field": "date","interval": "week"},"aggs": {"sum_of_dbcount": {"sum": {"field": "_dbcount"}}}}}}
                    var data = averageRankingService(environment.apiUri+'/powerme/statistics/_search');
                    data = JSON.parse(data);

                    for (var i = 0; i < data.aggregations.group_by_dbname.buckets.length; i++) {

				                var date1 = moment(data.aggregations.group_by_dbname.buckets[i].key_as_string,"YYYY-M-DD").format("YYYY,M,DD");
				                date1 = date1.split(',');
				                var month = date1[1] - 1;
				                var dateFormat = Date.UTC(date1[0], month,date1[2]);
				                dashBoardDaily_Calender.push([dateFormat,data.aggregations.group_by_dbname.buckets[i].sum_of_dbcount.value]);
                    }

                    angular
                        .element('#ReportsChart')
                        .highcharts({
                            chart: {
                                zoomType: 'x'

                            },

                            legend: {
                                enabled: false
                            },
                            title: {
                                text: 'Weekly Dashboard Statistics for '+res[0]+" "+res[1]
                            },
                            subtitle: {
                                text: document.ontouchstart === undefined ? 'Click and drag in the plot area to zoom in' : 'Pinch the chart to zoom in'
                            },

                            xAxis: {
                                type: 'datetime',

                                labels: {
                                    autoRotation: false
                                }
                            },
                            yAxis: {
                                title: {
                                    text: '# of Dashboard Hits'
                                },
                                min: 0,
                                allowDecimals: false,
                                labels: {
                                    formatter: function() {
                                        return this.value;
                                    }
                                }
                            },

                            legend: {
                                enabled: false
                            },

                            series: [{

                                name: 'Dashboard Usage',
                                data: dashBoardDaily_Calender
                            }]
                        });

                    // Graph code for Top 10 Dashboards by Unique Usage on Calender Filter

                    $rootScope.query = {"size": 0,"aggs": {"fl": {"filter": {"bool": {"must": [{"range": {"date": {"from": start_date,"to": end_date}}}],"must_not": [{"terms": {"_dbname": ["NA","","Welcome","1. Welcome","SSI-IB"]}}]}},"aggs": {"db": {"terms": {"field": "_dbname","size": 10,"order": {"users.value":"desc"}},"aggs": {"users": {"cardinality": {"field": "_name","precision_threshold":40000}}}}}}}};
                    var data = averageRankingService(environment.apiUri+'/powerme/statistics/_search');
                    data = JSON.parse(data);

                        for (var i = 0; i < data.aggregations.fl.db.buckets.length; i++) {

                        	unique_name_calender.push(data.aggregations.fl.db.buckets[i].key);
                        	unique_count_calender.push(data.aggregations.fl.db.buckets[i].users.value);

                            }

                        angular
                            .element('#ForthChart')
                            .highcharts({
                                chart: {
                                    type: 'column'
                                },
                                legend: {
                                    enabled: false
                                },
                                title: {
                                    text: 'Top 10 Dashboards by Number of Users for '+res[0]+" "+res[1]
                                },

                                xAxis: {
                                    categories: unique_name_calender,
                                    crosshair: true,
                                    labels: {
                                        autoRotation: false
                                    }

                                },
                                yAxis: {
                                    min: 0,
                                    allowDecimals: false,
                                    title: {
                                        text: '# of Unique Users'
                                    }
                                },
                                tooltip: {
                                    headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                                    pointFormat: '<tr><td style="color:{series.color};padding:0">Unique Usage: </td>' + '<td style="padding:0"><b>{point.y:.0f}</b></td></tr>',
                                    footerFormat: '</table>',
                                    shared: true,
                                    useHTML: true
                                },
                                plotOptions: {
                                    column: {
                                        pointPadding: 0.2,
                                        borderWidth: 0
                                    }
                                },
                                series: [{
                                    name: 'Dashboards',
                                    data: unique_count_calender

                                }]
                            });

     };



            $scope.getContent = function(type) {

            	console.log("TYPE ->"+type);
            	console.log($scope.options.filterCriteria);

                angular.element('#reportrange span').html(
                    moment().subtract(29, 'days').format(
                        'MMMM D, YYYY') + ' - ' + moment().format('MMMM D, YYYY'));
                $scope.appInfo = [];

                $scope.isApps = true;
                var category = [];

                // Application Filters
                var dashboard_applnFilter_name = [];
                var dashboard_applnFilter_count = [];
                var user_applnFilter_name = [];
                var user_applnFilter_count = [];
                var dashBoardMonthly_applnFilter_name = [];
                var dashBoardMonthly_applnFilter_count = [];
                var report_applnFilter_name = [];
                var report_applnFilter_count = [];

                //////////////////////////////////////////////////SYSTEM FILTER/////////////////////////////////////////////////////////////
//				////////////////////////////////////////////////SYSTEM FILTER/////////////////////////////////////////////////////////////
//				////////////////////////////////////////////////SYSTEM FILTER/////////////////////////////////////////////////////////////

                if($scope.options.filterCriteria == "System"){


                    	 //------------------------CARD 1--------------------------------------------------------
                        $rootScope.query = { "size":10000,"query": {"bool": {"must": [{"match": {"system_name": type}}]}}, "fields" : ["applications/sites.group.dashboard_group_name"]}
                        var data = averageRankingService(environment.apiUri+'/powerme/systems/_search');
                        data = JSON.parse(data);
                        var Dashboard_Group_Count_Card = 0;
                        var Dashboard_Group_Names = [];
                        for(var i=0; i<data.hits.hits.length;i++){
                        	var Test_Name = data.hits.hits[i].fields['applications/sites.group.dashboard_group_name'][0];
                        	if((Dashboard_Group_Names.indexOf(Test_Name))=== -1){
                        		Dashboard_Group_Names.push(Test_Name);
                        	}else{
                        		continue;
                        	}
                        }

                        $rootScope.SubjectAreaCount = Dashboard_Group_Names.length;

                        //---------------------CARD 2------------------------------------------------------------------
                        $rootScope.query = {"size":0,"query": {"bool": {"must": [{"match": {"system_name": type}}]}},"aggs":{"agg1": {"terms": {"field": "applications/sites.application/site_id","size":0}}}}

                        var data = averageRankingService(environment.apiUri+'/powerme/systems/_search');

                        data = JSON.parse(data);
                        $rootScope.applicationCount = data.aggregations.agg1.buckets.length;

                        //-------------------CARD 3-------------------------------------------------------------------
                        $rootScope.query = {"size":0,"query": {"bool": {"must": [{"match": {"system_name": type}}]}},"aggs":{"agg1": {"terms": {"field": "applications/sites.application/site_id","size":0}}}}

                        var data = averageRankingService(environment.apiUri+'/powerme/systems/_search');

                        data = JSON.parse(data);
                        var Dashboard_Count_Card = 0;
                        for(var i=0; i<data.aggregations.agg1.buckets.length; i++){
                        	Dashboard_Count_Card += data.aggregations.agg1.buckets[i].doc_count;
                        }
                        $rootScope.dashboardCount = Dashboard_Count_Card;

                        //--------------------CARD 4----------------------------------------------------------------------
                        $rootScope.query = { "size":10000,"query": {"bool": {"must": [{"match": {"system_name": type}}]}},"fields" : ["applications/sites.group.dashboards.dashboard_pages.reports.report_name"]}

                        var resultdata = averageRankingService(environment.apiUri+'/powerme/systems/_search');
                        //console.log(JSON.stringify(data));
                        resultdata = JSON.parse(resultdata);
                        //console.log(data);
                        var Report_Count_Card = 0;

                        for(var i=0; i<= resultdata.hits.hits.length; i++){
                        	  if(resultdata.hits.hits[i]!=undefined){
                        		  if(resultdata.hits.hits[i].fields!=undefined){
                              		Report_Count_Card += resultdata.hits.hits[i].fields["applications/sites.group.dashboards.dashboard_pages.reports.report_name"].length;
                              	}
                        	  }
                        }
                        $rootScope.reportCount = Report_Count_Card;


                        // Graph code for Top 10 Dashboards Filter : System
                        $scope.dashboardName_SystemFilter = [];
                        $scope.dashboardCount_SystemFilter = [];

                        $rootScope.query = {"size" : 0,"query": {"bool": {"must": [{"terms": {"repository_name": [type]}}],"must_not": [{"terms": {"_dbname": ["NA","","Welcome","1. Welcome","SSI-IB"]}}]}},"aggs": {"dashboard_names": {"terms": {"field": "repositories.applications.subject-areas.dashboards._dbname","order": {"result.value":"desc"},"size" : 10},"aggs": {"result": {"sum": {"field": "repositories.applications.subject-areas.dashboards._dbcount"}}}}}};

                        var data = averageRankingService(environment.apiUri+'/powerme/statistics/_search');

                        data = JSON.parse(data);

                        for (var i = 0; i < data.aggregations.dashboard_names.buckets.length; i++) {

                        	$scope.dashboardName_SystemFilter.push(data.aggregations.dashboard_names.buckets[i].key);
                        	$scope.dashboardCount_SystemFilter.push(data.aggregations.dashboard_names.buckets[i].result.value);

                            }



                        angular
                            .element('#container')
                            .highcharts({
                                chart: {
                                    type: 'column'
                                },
                                title: {
                                    text: 'Top 10 Dashboards in '+type
                                },
                                legend: {

                                    enabled: false
                                },

                                xAxis: {
                                    categories: $scope.dashboardName_SystemFilter,
                                    crosshair: true,
                                    labels: {
                                        autoRotation: false
                                    },
                                    offset: 0
                                },
                                yAxis: {
                                    min: 0,
                                    title: {
                                        text: '# of Dashboards Hits'
                                    },
                                    offset: 0
                                },
                                tooltip: {
                                    headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                                    pointFormat: '<tr><td style="color:{series.color};padding:0">Dashboard Hits: </td>' + '<td style="padding:0"><b>{point.y:.0f}</b></td></tr>',
                                    footerFormat: '</table>',
                                    shared: true,
                                    useHTML: true
                                },
                                plotOptions: {
                                    column: {
                                        pointPadding: 0.2,
                                        borderWidth: 0
                                    }
                                },
                                series: [{
                                    name: 'Dashboards',
                                    data: $scope.dashboardCount_SystemFilter

                                }]
                            });

                        // Code for Top 10 Users on Filter : System

                        $scope.UserNames_SystemFilter = [];
                        $scope.UserUsage_SystemFilter = [];
                        // AJAX CALL FOR TOP 10 USERS

                        $rootScope.query = {"size" : 0,"query": {"bool": {"must": [{"match": {"repository_name": type}}]}},"aggs": {"dashboard_names": {"terms": {"field": "repositories.applications.subject-areas.dashboards.users._name","order": {"result.value":"desc"},"size" : 10},"aggs": {"result": {"sum": {"field": "repositories.applications.subject-areas.dashboards.users._count"}}}}}};

                        var data = averageRankingService(environment.apiUri+'/powerme/statistics/_search');

                        data = JSON.parse(data);

                        for (var i = 0; i < data.aggregations.dashboard_names.buckets.length; i++) {

                        	$scope.UserNames_SystemFilter.push(data.aggregations.dashboard_names.buckets[i].key);
                        	$scope.UserUsage_SystemFilter.push(data.aggregations.dashboard_names.buckets[i].result.value);

                        }

                        angular
                            .element('#userChart')
                            .highcharts({

                                chart: {

                                    type: 'column'

                                },

                                title: {

                                    text: 'Top 10 Users in '+type

                                },

                                xAxis: {

                                    categories: $scope.UserNames_SystemFilter,

                                    crosshair: true,

                                    labels: {

                                        autoRotation: false

                                    },

                                    offset: 0

                                },

                                yAxis: {

                                    min: 0,

                                    title: {

                                        text: '# of Dashboard Hits'

                                    },

                                    offset: 0

                                },
                                legend: {

                                    enabled: false

                                },

                                tooltip: {

                                    headerFormat: '<span style="font-size:10px">{point.key}</span><table>',

                                    pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +

                                        '<td style="padding:0"><b>{point.y:.0f}</b></td></tr>',

                                    footerFormat: '</table>',

                                    shared: true,

                                    useHTML: true

                                },

                                plotOptions: {

                                    column: {

                                        pointPadding: 0.2,

                                        borderWidth: 0

                                    }

                                },

                                series: [{

                                    name: 'Users',

                                    data: $scope.UserUsage_SystemFilter

                                }]

                            });

                        // Code for System Filter Daily Usage (for all Applications)

                        $scope.DailyUsageCount_SystemFilter=[];
                        // AJAX CALL FOR TOP DASHBOARDS USAGE
                        $rootScope.query = {"size": 0,"query": {"bool": {"must": [{"match": {"repository_name": type}}]}},"aggs": {"group_by_dbname": {"date_histogram": {"field": "date","interval" : "week"},"aggs": {"sum_of_dbcount": {"sum": {"field": "_dbcount"}}}}}};
                        var data = averageRankingService(environment.apiUri+'/powerme/statistics/_search');
                        data = JSON.parse(data);

                        for (var i = 0; i < data.aggregations.group_by_dbname.buckets.length; i++) {
                            var date1 = moment(data.aggregations.group_by_dbname.buckets[i].key_as_string,"YYYY-M-DD").format("YYYY,M,DD");
                            date1 = date1.split(',');
                            var month = date1[1] - 1;
                            var dateFormat = Date.UTC(date1[0], month, date1[2]);
                            $scope.DailyUsageCount_SystemFilter.push([dateFormat,data.aggregations.group_by_dbname.buckets[i].sum_of_dbcount.value]);
                        }

                        angular
                            .element('#ReportsChart')
                            .highcharts({
                                chart: {
                                    zoomType: 'x'

                                },

                                legend: {
                                    enabled: false
                                },
                                title: {
                                    text: 'Weekly '+type+' Dashboard Usage'
                                },
                                subtitle: {
                                    text: document.ontouchstart === undefined ? 'Click and drag in the plot area to zoom in' : 'Pinch the chart to zoom in'
                                },

                                xAxis: {
                                    type: 'datetime',

                                    labels: {
                                        autoRotation: false
                                    }
                                },
                                yAxis: {
                                    title: {
                                        text: '# of Dashboard Hits'
                                    },
                                    min: 0,
                                    labels: {
                                        formatter: function() {
                                            return this.value;
                                        }
                                    }
                                },

                                legend: {
                                    enabled: false
                                },

                                series: [{

                                    name: 'Daily Dashboard Usage',
                                    data: $scope.DailyUsageCount_SystemFilter
                                }]
                            });

                        // Unique User [System Filter]

                        var app = angular.element('#minovate');
                        $scope.UniqueUserNames_SystemFilter=[];
                        $scope.UniqueUserCount_SystemFilter=[];
                        // AJAX CALL FOR Top 10 Dashboards [Overall]

                        $rootScope.query = {"size": 0,"aggs": {"fl": {"filter": {"bool": {"must": [{"terms": {"repository_name": [type]}}],"must_not": [{"terms": {"_dbname": ["NA","","Welcome","1. Welcome","SSI-IB"]}}]}},"aggs": {"db": {"terms": {"field": "_dbname","size": 10,"order": {"users.value":"desc"}},"aggs": {"users": {"cardinality": {"field": "_name","precision_threshold":40000}}}}}}}};

                        var data = averageRankingService(environment.apiUri+'/powerme/statistics/_search');

                        data = JSON.parse(data);

                        for (var i = 0; i < data.aggregations.fl.db.buckets.length; i++) {

                        	$scope.UniqueUserNames_SystemFilter.push(data.aggregations.fl.db.buckets[i].key);
                            $scope.UniqueUserCount_SystemFilter.push(data.aggregations.fl.db.buckets[i].users.value);

                            }


                        angular
                            .element('#ForthChart')
                            .highcharts({
                                chart: {
                                    type: 'column'
                                },
                                title: {
                                    text: 'Top 10 Unique Used Dashboards in '+type
                                },
                                legend: {

                                    enabled: false
                                },

                                xAxis: {
                                    categories: $scope.UniqueUserNames_SystemFilter,
                                    crosshair: true,
                                    labels: {
                                        autoRotation: false
                                    },
                                    offset: 0
                                },
                                yAxis: {
                                    min: 0,
                                    title: {
                                        text: '# of Unique Users'
                                    },
                                    offset: 0
                                },
                                tooltip: {
                                    headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                                    pointFormat: '<tr><td style="color:{series.color};padding:0">Unique Users: </td>' + '<td style="padding:0"><b>{point.y:.0f}</b></td></tr>',
                                    footerFormat: '</table>',
                                    shared: true,
                                    useHTML: true
                                },
                                plotOptions: {
                                    column: {
                                        pointPadding: 0.2,
                                        borderWidth: 0
                                    }
                                },
                                series: [{
                                    name: 'Dashboards',
                                    data: $scope.UniqueUserCount_SystemFilter

                                }]
                            });
                     }

                //else if (type === "BU" || type === "Compass" || type === "Entitlement" || type === "MDM" || type === "VMDASH" || type === "Webflash" || type === "Production") {

                else{

                	var Applications_Checked = [];
                	var Applications_Checked_Statistics = [];
                	for(key in type){
                		if(type[key] == true){
                			Applications_Checked.push(key);
                			Applications_Checked_Statistics.push(key);
                		}
                	}

               

  //              	   ------------------------ CARD 1 -------------------------------------------------


                	   var testing = "";
                   	var main = '{"size": 10000,"query": {"bool": {"should": [';
                   	var trail = ']}},"fields": ["applications/sites.group.dashboard_group_name"]}';


                   	  for(var i=0; i< Applications_Checked.length; i++)
                   	  {
                   	      if(i!= Applications_Checked.length-1)
                   	      testing+= "{"+'"'+"match"+'"'+":"+"{"+'"'+"applications/sites.application/site_id"+'"'+":"+'"'+Applications_Checked[i]+'"'+"}},"
                   	      else{ testing+= "{"+'"'+"match"+'"'+":"+"{"+'"'+"applications/sites.application/site_id"+'"'+":"+'"'+Applications_Checked[i]+'"'+"}}"}}

                   	  var query1 = main+testing+trail;
                   	   query1 = JSON.parse(query1);
                   	   $rootScope.query = query1;
                   	   var data1 = averageRankingService(environment.apiUri+'/powerme/systems/_search');
                   	   data1 = JSON.parse(data1);

                   	var Dashboard_Group_Count_Card = 0;
                    var Dashboard_Group_Names = [];
                    for(var i=0; i<data1.hits.hits.length;i++){
                    	var Test_Name = data1.hits.hits[i].fields['applications/sites.group.dashboard_group_name'][0];
                    	if((Dashboard_Group_Names.indexOf(Test_Name))=== -1){
                    		Dashboard_Group_Names.push(Test_Name);
                    	}else{
                    		continue;
                    	}
                    }

                    $rootScope.SubjectAreaCount = Dashboard_Group_Names.length;


 //              	   ------------------------ CARD 2 -------------------------------------------------


                	   var testing = "";
                   	var main = '{"size":0,"query": {"bool": {"should":  [';
                   	var trail = ']}},"aggs": {"agg1": {"terms": {"field": "repositories.applications.application","size": 0}}}}';


                   	  for(var i=0; i< Applications_Checked_Statistics.length; i++)
                   	  {
                   	      if(i!= Applications_Checked_Statistics.length-1)
                   	      testing+= "{"+'"'+"match"+'"'+":"+"{"+'"'+"application"+'"'+":"+'"'+Applications_Checked_Statistics[i]+'"'+"}},"
                   	      else{ testing+= "{"+'"'+"match"+'"'+":"+"{"+'"'+"application"+'"'+":"+'"'+Applications_Checked_Statistics[i]+'"'+"}}"}}

                   	  var query1 = main+testing+trail;
                   	   query1 = JSON.parse(query1);
                   	   $rootScope.query = query1;
                   	   var data1 = averageRankingService(environment.apiUri+'/powerme/statistics/_search');
                   	   data1 = JSON.parse(data1);
                   	   $rootScope.applicationCount = Applications_Checked.length;

 //              	   ------------------------ CARD 3 -------------------------------------------------


                	   var testing = "";
                   	var main = '{"size":0,"query": {"bool": {"should": [';
                   	var trail = ']}},"aggs":{"agg1": {"terms": {"field": "applications/sites.application/site_id","size":0}}}}';


                   	  for(var i=0; i< Applications_Checked.length; i++)
                   	  {
                   		  if(i!= Applications_Checked.length-1)
                   			  testing+= "{"+'"'+"match"+'"'+":"+"{"+'"'+"applications/sites.application/site_id"+'"'+":"+'"'+Applications_Checked[i]+'"'+"}},"
                   	      else{ testing+= "{"+'"'+"match"+'"'+":"+"{"+'"'+"applications/sites.application/site_id"+'"'+":"+'"'+Applications_Checked[i]+'"'+"}}"}}

                   	  var query1 = main+testing+trail;

                   	   query1 = JSON.parse(query1);
                   	   $rootScope.query = query1;
                   	   var data1 = averageRankingService(environment.apiUri+'/powerme/systems/_search');
                   	   data1 = JSON.parse(data1);

                   	   var Dashboard_Count_Card = 0;
                     for(var i=0; i<data1.aggregations.agg1.buckets.length; i++){
                     	Dashboard_Count_Card += data1.aggregations.agg1.buckets[i].doc_count;
                     }
                     $rootScope.dashboardCount = Dashboard_Count_Card;


 //              	   ------------------------ CARD 4 -------------------------------------------------


                	   var testing = "";
                   	var main = '{ "size":10000,"query": {"bool": {"should": [';
                   	var trail = ']}},"fields" : ["applications/sites.group.dashboards.dashboard_pages.reports.report_name"]}';


                   	  for(var i=0; i< Applications_Checked.length; i++)
                   	  {
                   	      if(i!= Applications_Checked.length-1)
                   	      testing+= "{"+'"'+"match"+'"'+":"+"{"+'"'+"applications/sites.application/site_id"+'"'+":"+'"'+Applications_Checked[i]+'"'+"}},"
                   	      else{ testing+= "{"+'"'+"match"+'"'+":"+"{"+'"'+"applications/sites.application/site_id"+'"'+":"+'"'+Applications_Checked[i]+'"'+"}}"}}

                   	  var query1 = main+testing+trail;

                   	  query1 = JSON.parse(query1);

                   	   $rootScope.query = query1;
                   	   var Report_Count_Card=0;
                   	   var data = averageRankingService(environment.apiUri+'/powerme/systems/_search');
                   	   data = JSON.parse(data);


		                   	for(var i=0; i<= data.hits.hits.length; i++){
		                  	  if(data.hits.hits[i]!=undefined){
		                  		  if(data.hits.hits[i].fields!=undefined){
		                  			  Report_Count_Card += data.hits.hits[i].fields["applications/sites.group.dashboards.dashboard_pages.reports.report_name"].length;
		                        	}
		                  	  }
		                  }
		                  $rootScope.reportCount = Report_Count_Card;




                    //---------------------------------- Code for Top 10 Dashboards Filter : Application

                   	// AJAX CALL FOR TOP 10 DASHBOARDS
                       $scope.DashboardNames_ApplicationFilter = [];
                       var count = 0;
                       $scope.DashboardCount_ApplicationFilter = [];



                   	var testing = "";
                	var main = '{"size":0,"query": {"bool": {"should":  [';
                	var trail = '],"must_not": [{"term": {"_dbname": "NA"}},{"term": {"_dbname": "Welcome"}},{"term": {"_dbname": "SSI-IB"}},{"term": {"_dbname": "1. Welcome"}}]}},"aggs": {"dashboard_names": {"terms": {"field": "repositories.applications.subject-areas.dashboards._dbname","order": {"result.value":"desc"},"size" : 10},"aggs": {"result": {"sum": {"field": "repositories.applications.subject-areas.dashboards._dbcount"}}}}}}';


                	  for(var i=0; i< Applications_Checked_Statistics.length; i++)
                	  {
                	      if(i!= Applications_Checked_Statistics.length-1)
                	      testing+= "{"+'"'+"match"+'"'+":"+"{"+'"'+"application"+'"'+":"+'"'+Applications_Checked_Statistics[i]+'"'+"}},"
                	      else{ testing+= "{"+'"'+"match"+'"'+":"+"{"+'"'+"application"+'"'+":"+'"'+Applications_Checked_Statistics[i]+'"'+"}}"}}

                	  var query1 = main+testing+trail;
                	   query1 = JSON.parse(query1);
                	   $rootScope.query = query1;
                	   var data1 = averageRankingService(environment.apiUri+'/powerme/statistics/_search');
                	   data1 = JSON.parse(data1);




                    for (var i = 0; i < data1.aggregations.dashboard_names.buckets.length; i++) {


                    	$scope.DashboardNames_ApplicationFilter.push(data1.aggregations.dashboard_names.buckets[i].key);
                        $scope.DashboardCount_ApplicationFilter.push(data1.aggregations.dashboard_names.buckets[i].result.value);
                    }

                    angular
                        .element('#container')
                        .highcharts({
                            chart: {
                                type: 'column'
                            },
                            title: {
                                text: 'Top 10 Dashboards by Application Usage'
                            },
                            legend: {

                                enabled: false
                            },

                            xAxis: {
                                categories: $scope.DashboardNames_ApplicationFilter,
                                crosshair: true,
                                labels: {
                                    autoRotation: false
                                },
                                offset: 0
                            },
                            yAxis: {
                                min: 0,
                                title: {
                                    text: '# of Dashboard Hits'
                                },
                                offset: 0
                            },
                            tooltip: {
                                headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                                pointFormat: '<tr><td style="color:{series.color};padding:0">Dashboard Hits: </td>' + '<td style="padding:0"><b>{point.y:.0f}</b></td></tr>',
                                footerFormat: '</table>',
                                shared: true,
                                useHTML: true
                            },
                            plotOptions: {
                                column: {
                                    pointPadding: 0.2,
                                    borderWidth: 0
                                }
                            },
                            series: [{
                                name: 'Dashboards',
                                data: $scope.DashboardCount_ApplicationFilter

                            }]
                        });

                   // ----------------------------------------------Code for Top 10 Users on Filter : Application

                    $scope.UserNames_ApplicationFilter = [];
                    $scope.UserCount_ApplicationFilter = [];



                var testing = "";
             	var main = '{"size":0,"query": {"bool": {"should":  [';
             	var trail = ']}},"aggs": {"dashboard_names": {"terms": {"field": "repositories.applications.subject-areas.dashboards.users._name","order": {"result.value":"desc"},"size" : 10},"aggs": {"result": {"sum": {"field": "repositories.applications.subject-areas.dashboards.users._count"}}}}}}';


             	  for(var i=0; i< Applications_Checked_Statistics.length; i++)
             	  {
             	      if(i!= Applications_Checked_Statistics.length-1)
             	      testing+= "{"+'"'+"match"+'"'+":"+"{"+'"'+"application"+'"'+":"+'"'+Applications_Checked_Statistics[i]+'"'+"}},"
             	      else{ testing+= "{"+'"'+"match"+'"'+":"+"{"+'"'+"application"+'"'+":"+'"'+Applications_Checked_Statistics[i]+'"'+"}}"}}

	             	  var query1 = main+testing+trail;
	             	   query1 = JSON.parse(query1);
	             	   $rootScope.query = query1;
	             	   var data1 = averageRankingService(environment.apiUri+'/powerme/statistics/_search');
	             	   data1 = JSON.parse(data1);




                 for (var i = 0; i < data1.aggregations.dashboard_names.buckets.length; i++) {


                	 $scope.UserNames_ApplicationFilter.push(data1.aggregations.dashboard_names.buckets[i].key);
                	 $scope.UserCount_ApplicationFilter.push(data1.aggregations.dashboard_names.buckets[i].result.value);
                 }


                    angular
                        .element('#userChart')
                        .highcharts({

                            chart: {

                                type: 'column'

                            },

                            title: {

                                text: 'Top 10 Users of Application'

                            },

                            xAxis: {

                                categories: $scope.UserNames_ApplicationFilter,

                                crosshair: true,

                                labels: {

                                    autoRotation: false

                                },

                                offset: 0

                            },

                            yAxis: {

                                min: 0,

                                title: {

                                    text: '# of Dashboard Hits'

                                },

                                offset: 0

                            },
                            legend: {

                                enabled: false

                            },

                            tooltip: {

                                headerFormat: '<span style="font-size:10px">{point.key}</span><table>',

                                pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +

                                    '<td style="padding:0"><b>{point.y:.0f}</b></td></tr>',

                                footerFormat: '</table>',

                                shared: true,

                                useHTML: true

                            },

                            plotOptions: {

                                column: {

                                    pointPadding: 0.2,

                                    borderWidth: 0

                                }

                            },

                            series: [{

                                name: 'Users',

                                data: $scope.UserCount_ApplicationFilter

                            }]

                        });


                    // ----------------------------------------------Code for Daily Usage : Application

        $scope.TimeDate_ApplicationFilter = [];
        $scope.TimeCount_ApplicationFilter = [];



                var testing = "";
             	var main = '{"size":0,"query": {"bool": {"must":  [{"terms": {"application": [';
             	var trail = ']}}]}},"aggs": {"group_by_dbname": {"date_histogram": {"field": "date","interval": "week"},"aggs": {"sum_of_dbcount": {"sum": {"field": "_dbcount"}}}}}}';



             	  for(var i=0; i< Applications_Checked_Statistics.length; i++){
             	      if(i!= Applications_Checked_Statistics.length-1)
             	      testing+= '"'+Applications_Checked_Statistics[i]+'"'+","
             	      else{ testing+= '"'+Applications_Checked_Statistics[i]+'"';}  }

	             	  var query1 = main+testing+trail;
	             	   query1 = JSON.parse(query1);
	             	   $rootScope.query = query1;
	             	   var data1 = averageRankingService(environment.apiUri+'/powerme/statistics/_search');
	             	   data1 = JSON.parse(data1);




                 for (var i = 0; i < data1.aggregations.group_by_dbname.buckets.length; i++) {

                	  var date1 = moment(data1.aggregations.group_by_dbname.buckets[i].key_as_string,"YYYY-M-DD").format("YYYY,M,DD");
                          date1 = date1.split(',');
                          var month = date1[1] - 1;
                          var dateFormat = Date.UTC(date1[0], month, date1[2]);
                          $scope.TimeDate_ApplicationFilter.push([dateFormat,data1.aggregations.group_by_dbname.buckets[i].sum_of_dbcount.value]);
                      }


                    angular
                        .element('#ReportsChart')
                        .highcharts({

                            chart: {

                                zoomType: 'x'
                            },

                            title: {
                                text: 'Weekly Application Usage Statistics'

                            },

                            subtitle: {

                                text: document.ontouchstart === undefined ?

                                    'Click and drag in the plot area to zoom in' : 'Pinch the chart to zoom in'

                            },

                            xAxis: {

                                type: 'datetime',

                                labels: {

                                    autoRotation: false

                                },

                                offset: 0

                            },

                            yAxis: {

                                title: {

                                    text: '# of Dashboard Hits',

                                },

                                min: 0,

                                labels: {

                                    formatter: function() {

                                        return this.value;

                                    }

                                },

                                offset: 0

                            },

                            legend: {

                                enabled: false

                            },


                            series: [{

                                 name: 'Dashboard Usage',

                                data: $scope.TimeDate_ApplicationFilter

                            }]

                        }); // Graph Endpoint

                 // ----------------------------------------------Code for Unique Usage : Application
                    // Top 10 Reports for Application
                    $scope.UniqueUserNames_ApplicationFilter = [];
                    $scope.UniqueUserCount_ApplicationFilter = [];



                var testing = "";
             	var main = '{"size": 0,"aggs": {"fl": {"filter": {"bool": {"must": [{"terms": {"application": [';
             	var trail = ']}}],"must_not": [{"term": {"_dbname": "NA"}},{"term": {"_dbname": "Welcome"}},{"term": {"_dbname": "SSI-IB"}},{"term": {"_dbname": "1. Welcome"}}]}},"aggs": {"db": {"terms": {"field": "_dbname","size": 10,"order": {"users.value":"desc"}},"aggs": {"users": {"cardinality": {"field": "_name","precision_threshold":40000}}}}}}}}';


             	  for(var i=0; i< Applications_Checked_Statistics.length; i++)
             	  {
             	      if(i!= Applications_Checked_Statistics.length-1)
             	      testing+= '"'+Applications_Checked_Statistics[i]+'"'+",";
             	      else{ testing+= '"'+Applications_Checked_Statistics[i]+'"';}}

	             	  var query1 = main+testing+trail;
	             	   query1 = JSON.parse(query1);
	             	   $rootScope.query = query1;
	             	   var data = averageRankingService(environment.apiUri+'/powerme/statistics/_search');
	             	   data = JSON.parse(data);

                 for (var i = 0; i < data.aggregations.fl.db.buckets.length; i++) {

                	 $scope.UniqueUserNames_ApplicationFilter.push(data.aggregations.fl.db.buckets[i].key);
                	 $scope.UniqueUserCount_ApplicationFilter.push(data.aggregations.fl.db.buckets[i].users.value);
                 }


                    angular
                        .element('#ForthChart')
                        .highcharts({

                            chart: {

                                type: 'column'

                            },

                            title: {

                                text: 'Top 10 Dashboards by Number of Users'

                            },

                            xAxis: {

                                categories: $scope.UniqueUserNames_ApplicationFilter,

                                crosshair: true,

                                labels: {

                                    autoRotation: false

                                },

                                offset: 0

                            },

                            yAxis: {

                                min: 0,

                                title: {

                                    text: '# of Unique Users'

                                },

                                offset: 0

                            },
                            legend: {

                                enabled: false

                            },

                            tooltip: {

                                headerFormat: '<span style="font-size:10px">{point.key}</span><table>',

                                pointFormat: '<tr><td style="color:{series.color};padding:0">Unique Users: </td>' +

                                    '<td style="padding:0"><b>{point.y:.0f}</b></td></tr>',

                                footerFormat: '</table>',

                                shared: true,

                                useHTML: true

                            },

                            plotOptions: {

                                column: {

                                    pointPadding: 0.2,

                                    borderWidth: 0

                                }

                            },

                            series: [{

                                name: 'Unique Dashboards',

                                data: $scope.UniqueUserCount_ApplicationFilter

                            }]

                        });
                    
                    //-----5th Chart -------- Filter : Application
                    
                    $scope.Chart5_FinalData = [];
                    $scope.Chart6_FinalData = [];
                    $scope.Chart7_FinalData = [];
                    var chartSelector = "";
                    $scope.getChartSelector = function(){
                    	
                    	if($scope.options.ChartSelector == "ChartSelector_DashboardHits"){
                    		
                    		for(var i=0; i< Applications_Checked_Statistics.length; i++){
                        		var query5 = '{"size":0,"query": {"bool": {"must":  [{"terms": {"application": ['+'"'+Applications_Checked_Statistics[i]+'"'+']}}]}},"aggs": {"group_by_dbname": {"date_histogram": {"field": "date","interval": "week"},"aggs": {"sum_of_dbcount": {"sum": {"field": "_dbcount"}}}}}}';
                        		query5 = JSON.parse(query5);
                        		$rootScope.query = query5;
                        		var data5 = averageRankingService(environment.apiUri+'/powerme/statistics/_search');
                        		data5 = JSON.parse(data5);
                        		console.log(data5.aggregations.group_by_dbname.buckets.length);
                        		var dateFormat = [];
                        		for (var j = 0; j < data5.aggregations.group_by_dbname.buckets.length; j++) {

                              	        var date1 = moment(data5.aggregations.group_by_dbname.buckets[j].key_as_string,"YYYY-M-DD").format("YYYY,M,DD");
                                        date1 = date1.split(',');
                                        var month = date1[1] - 1;
                                        var date = Date.UTC(date1[0], month, date1[2]);
                                        
                                        dateFormat.push([date,data5.aggregations.group_by_dbname.buckets[j].sum_of_dbcount.value]);
                                        
                                     }
                        		
                        		$scope.Chart5_FinalData.push({
                                	name: Applications_Checked_Statistics[i],
                                	data: dateFormat
                                });
                        	}
                        

        	                 angular
                                .element('#FifthChartId')
                                .highcharts({

                                    chart: {

                                        zoomType: 'x'
                                    },

                                    title: {
                                        text: 'Compares Dashboard Hits across Applications'

                                    },

                                    subtitle: {

                                        text: document.ontouchstart === undefined ?

                                            'Click and drag in the plot area to zoom in' : 'Pinch the chart to zoom in'

                                    },

                                    xAxis: {

                                        type: 'datetime',

                                        labels: {

                                            autoRotation: false

                                        },

                                        offset: 0

                                    },

                                    yAxis: {

                                        title: {

                                            text: '# of Dashboard Hits',

                                        },

                                        min: 0,

                                        labels: {

                                            formatter: function() {

                                                return this.value;

                                            }

                                        },

                                        offset: 0

                                    },

                                    legend: {

 align: 'right',
            verticalAlign: 'top',
            layout: 'vertical',
                                        enabled: true

                                    },


                                    series: $scope.Chart5_FinalData

                                    

                                }); // Graph Endpoint
                    		
                    	}
                    	
                    	else if($scope.options.ChartSelector == "ChartSelector_UserCount"){
                    		

                    		
                    		for(var i=0; i< Applications_Checked_Statistics.length; i++){
	                    		var query6 = '{"size":0,"query": {"bool": {"must":  [{"terms": {"application": ['+'"'+Applications_Checked_Statistics[i]+'"'+']}}]}},"aggs": {"group_by_dbname": {"date_histogram": {"field": "date","interval": "week"},"aggs": {"sum_of_dbcount": {"terms": {"field": "_name","size":0}}}}}}';
	                    		query6 = JSON.parse(query6);
	                    		$rootScope.query = query6;
	                    		var data6 = averageRankingService(environment.apiUri+'/powerme/statistics/_search');
	                    		data6 = JSON.parse(data6);
	                    		console.log(data6.aggregations.group_by_dbname.buckets.length);
	                    		var dateFormat = [];
	                    		for (var j = 0; j < data6.aggregations.group_by_dbname.buckets.length; j++) {

	                          	        var date1 = moment(data6.aggregations.group_by_dbname.buckets[j].key_as_string,"YYYY-M-DD").format("YYYY,M,DD");
	                                    date1 = date1.split(',');
	                                    var month = date1[1] - 1;
	                                    var date = Date.UTC(date1[0], month, date1[2]);
	                                    
	                                    dateFormat.push([date,data6.aggregations.group_by_dbname.buckets[j].sum_of_dbcount.buckets.length]);
	                                    
	                                 }
	                    		
	                    		$scope.Chart6_FinalData.push({
	                            	name: Applications_Checked_Statistics[i],
	                            	data: dateFormat
	                            });
	                    	}
                        

        	                 angular
                                .element('#FifthChartId')
                                .highcharts({

                                    chart: {

                                        zoomType: 'x'
                                    },

                                    title: {
                                        text: 'Compares User Counts across Applications'

                                    },

                                    subtitle: {

                                        text: document.ontouchstart === undefined ?

                                            'Click and drag in the plot area to zoom in' : 'Pinch the chart to zoom in'

                                    },

                                    xAxis: {

                                        type: 'datetime',

                                        labels: {

                                            autoRotation: false

                                        },

                                        offset: 0

                                    },

                                    yAxis: {

                                        title: {

                                            text: '# of Users',

                                        },

                                        min: 0,

                                        labels: {

                                            formatter: function() {

                                                return this.value;

                                            }

                                        },

                                        offset: 0

                                    },

                                    legend: {

 align: 'right',
            verticalAlign: 'top',
            layout: 'vertical',
                                        enabled: true

                                    },


                                    series: $scope.Chart6_FinalData

                                    

                                }); // Graph Endpoint
                    		
                    	
                    	}
                    	
                    	else if($scope.options.ChartSelector == "ChartSelector_Both"){
                    		
                    		var colorArray = ['#F241DE','#F2AD41', '#1CED11', '#112EED', '#050712', '#2AE8D2', '#FF0000'];
                    		
                    		for(var i=0; i< Applications_Checked_Statistics.length; i++){
	                    		var query7A = '{"size":0,"query": {"bool": {"must":  [{"terms": {"application": ['+'"'+Applications_Checked_Statistics[i]+'"'+']}}]}},"aggs": {"group_by_dbname": {"date_histogram": {"field": "date","interval": "week"},"aggs": {"sum_of_dbcount": {"terms": {"field": "_name","size":0}}}}}}';
	                    		query7A = JSON.parse(query7A);
	                    		$rootScope.query = query7A;
	                    		var data7A = averageRankingService(environment.apiUri+'/powerme/statistics/_search');
	                    		data7A = JSON.parse(data7A);
	                    		var dateFormat = [];
	                    		for (var j = 0; j < data7A.aggregations.group_by_dbname.buckets.length; j++) {

	                          	        var date1 = moment(data7A.aggregations.group_by_dbname.buckets[j].key_as_string,"YYYY-M-DD").format("YYYY,M,DD");
	                                    date1 = date1.split(',');
	                                    var month = date1[1] - 1;
	                                    var date = Date.UTC(date1[0], month, date1[2]);
	                                    
	                                    dateFormat.push([date,data7A.aggregations.group_by_dbname.buckets[j].sum_of_dbcount.buckets.length]);
	                                    
	                                 }
	                    		
	                    		$scope.Chart7_FinalData.push({
	                            	name: Applications_Checked_Statistics[i]+" User Hits",
	                            	data: dateFormat,
	                            	color: colorArray[i]
	                            });
	                    		
	                    		var query7B = '{"size":0,"query": {"bool": {"must":  [{"terms": {"application": ['+'"'+Applications_Checked_Statistics[i]+'"'+']}}]}},"aggs": {"group_by_dbname": {"date_histogram": {"field": "date","interval": "week"},"aggs": {"sum_of_dbcount": {"sum": {"field": "_dbcount"}}}}}}';
	                    		query7B = JSON.parse(query7B);
	                    		$rootScope.query = query7B;
	                    		var data7B = averageRankingService(environment.apiUri+'/powerme/statistics/_search');
	                    		data7B = JSON.parse(data7B);
	                    		var dateFormat = [];
	                    		for (var j = 0; j < data7B.aggregations.group_by_dbname.buckets.length; j++) {

	                          	        var date1 = moment(data7B.aggregations.group_by_dbname.buckets[j].key_as_string,"YYYY-M-DD").format("YYYY,M,DD");
	                                    date1 = date1.split(',');
	                                    var month = date1[1] - 1;
	                                    var date = Date.UTC(date1[0], month, date1[2]);
	                                    
	                                    dateFormat.push([date,data7B.aggregations.group_by_dbname.buckets[j].sum_of_dbcount.value]);
	                                    
	                                 }
	                    		
	                    		$scope.Chart7_FinalData.push({
	                            	name: Applications_Checked_Statistics[i]+" Dashboard Usage",
	                            	data: dateFormat,
	                            	color: colorArray[i]
	                            });

	                    	}
                    		
                    		 angular
                             .element('#FifthChartId')
                             .highcharts({

                                 chart: {

                                     zoomType: 'x'
                                 },

                                 title: {
                                     text: 'Compares Dashboard Hits & User Counts across Applications'

                                 },

                                 subtitle: {

                                     text: document.ontouchstart === undefined ?

                                         'Click and drag in the plot area to zoom in' : 'Pinch the chart to zoom in'

                                 },

                                 xAxis: {

                                     type: 'datetime',

                                     labels: {

                                         autoRotation: false

                                     },

                                     offset: 0

                                 },

                                 yAxis: {

                                     title: {

                                         text: '# of Users / # of Hits',

                                     },

                                     min: 0,

                                     labels: {

                                         formatter: function() {

                                             return this.value;

                                         }

                                     },

                                     offset: 0

                                 },

                                 legend: {
 align: 'right',
            verticalAlign: 'top',
            layout: 'vertical',
                                     enabled: true

                                 },


                                 series: $scope.Chart7_FinalData

                                 

                             }); // Graph Endpoint

                    		                    	
                    	}
                    	
                    } // End point for function()
                    
                } // End point for if = Application Selector 

                // -------------------------------------------------------------------------------------------------------------------------//
            };

           // console.log($rootScope.Filter + "//////////" + $rootScope.CalenderFilter);

        })
    .controller('cardsStatisticsCntrl',function($scope, $http, $rootScope) {

    })

// GRAPH 1 // // GRAPH 1 // // GRAPH 1 // // GRAPH 1 // // GRAPH 1 // // // GRAPH 1 // // GRAPH 1 // // GRAPH 1 // // GRAPH 1 //
.controller('StatisticsChartCtrl',function($scope, $http, $rootScope, averageRankingService) {

        var app = angular.element('#minovate');
        $scope.dashboardNames=[];
        $scope.dashboardCount=[];



        var Color_ApplicationNames=[];
        // AJAX CALL FOR Top 10 Dashboards [Overall]

        $rootScope.query = {"size" : 0,"query": {"bool": {"must_not": [{"terms": {"repositories.applications.subject-areas.dashboards.dashboard_id":["/Entitlement/ Welcome/_portal/   Welcome","NA","/Compass/Marketing/_portal/Welcome","/Entitlement/SSI/_portal/SSI-IB","/VMDASH/1. Welcome/_portal/1. Welcome"]}}]}}, "aggs": {"dashboard_names": {"terms": {"field": "repositories.applications.subject-areas.dashboards._dbname","order": {"result.value":"desc"},"size" : 10},"aggs": {"result": {"sum": {"field": "repositories.applications.subject-areas.dashboards._dbcount"}}}}}};
        var data = averageRankingService(environment.apiUri+'/powerme/statistics/_search');
        data = JSON.parse(data);

        var Application_Names = $rootScope.ApplicationNames;
        //console.log(Application_Names);
        for (var i = 0; i < data.aggregations.dashboard_names.buckets.length; i++) {

        	$scope.dashboardNames.push(data.aggregations.dashboard_names.buckets[i].key);
        	$scope.dashboardCount.push(data.aggregations.dashboard_names.buckets[i].result.value);

        }
        /*
        for (var i = 0; i < data.aggregations.dashboard_names.buckets.length; i++) {


        	var dashboard_id = data.aggregations.dashboard_names.buckets[i].key;
        	var dashboard_items = dashboard_id.split("/");
        	$scope.dashboardNames.push(dashboard_items[4]);
        	var ApplicationColor = $rootScope.Colors[Application_Names.indexOf(dashboard_items[1])];

        	ApplicationColor = ApplicationColor.toString();
        	$scope.dashboardCount.push({ y: data.aggregations.dashboard_names.buckets[i].result.value, color: ApplicationColor });

            }
        */

        angular
            .element('#container')
            .highcharts({
                chart: {
                    type: 'column'
                },
                title: {
                    text: 'Top 10 Dashboards by Number of Hits'
                },

                xAxis: {
                    categories: $scope.dashboardNames,

                	crosshair: true,
                	labels: {
                		autoRotation: false
                	},
                	offset: 0
                    
                },
                legend: {

                    enabled: false
                },

                yAxis: {
                    min: 0,
                    title: {
                        text: '# of Dashboard Hits'
                    },
                	crosshair: true,
                	labels: {
                		autoRotation: false
                	},
                	offset: 0
                },
                tooltip: {
                    headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                    pointFormat: '<tr><td style="color:{series.color};padding:0">Dashboard Hits: </td>' + '<td style="padding:0"><b>{point.y:.0f}</b></td></tr>',
                    footerFormat: '</table>',
                    shared: true,
                    useHTML: true
                },
                plotOptions: {
                     coloumn: {
                        datalabels:{
                        	enabled:true
                        }
                    }
                },
                series: [{
                    name: 'Dashboards',
                    data: $scope.dashboardCount

                }]
            });
    })

// GRAPH 2 // // GRAPH 2 // // GRAPH 2 // // GRAPH 2 // // GRAPH 2 // //GRAPH 2 // // GRAPH 2 // // GRAPH 2 // // GRAPH 2 //

.controller(
    'UserStatisticsChartCtrl',
    function($scope, $http, $rootScope, averageRankingService) {
        var app = angular.element('#minovate');
        $scope.UserCount = [];
        $scope.UserNames = [];
        // AJAX CALL FOR TOP 10 USERS

        $rootScope.query = {"size" : 0,"query": {"bool": {"must_not": [{"terms": {"_name": ["weblogic","tableauadmin"]}}]}}, "aggs": {"dashboard_names": {"terms": {"field": "repositories.applications.subject-areas.dashboards.users._name","order": {"result.value":"desc"},"size" : 10},"aggs": {"result": {"sum": {"field": "repositories.applications.subject-areas.dashboards.users._count"}}}}}};

        var data = averageRankingService(environment.apiUri+'/powerme/statistics/_search');

        data = JSON.parse(data);

        for (var i = 0; i < data.aggregations.dashboard_names.buckets.length; i++) {

            $scope.UserNames.push(data.aggregations.dashboard_names.buckets[i].key);

            $scope.UserCount.push(data.aggregations.dashboard_names.buckets[i].result.value);

        }

        angular
            .element('#userChart')
            .highcharts({

                chart: {
                    type: 'column'
                },
                title: {
                    text: 'Top 10 Users by Overall Usage'
                },

                xAxis: {
                    categories: $scope.UserNames,
                    crosshair: true,
                    labels: {
                        autoRotation: false
                    },
                    offset: 0
                },
                yAxis: {
                    min: 0,
                    title: {
                        text: '# of Dashboard Hits'
                    },
                    offset: 0
                },
                legend: {

                    enabled: false
                },

                tooltip: {
                    headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                    pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' + '<td style="padding:0"><b>{point.y:.0f}</b></td></tr>',
                    footerFormat: '</table>',
                    shared: true,
                    useHTML: true
                },
                plotOptions: {
                    column: {
                        pointPadding: 0.2,
                        borderWidth: 0
                    }
                },
                series: [{
                    name: 'Users',
                    data: $scope.UserCount

                }]

            });
    })

// GRAPH 3 // // GRAPH 3 // // GRAPH 3 // // GRAPH 3 // // GRAPH 3 // //GRAPH 3 // // GRAPH 3 // // GRAPH //

.controller(
        'ReportsStatisticsChartCtrl',
        function($scope, $http, $rootScope, averageRankingService) {
            var app = angular.element('#minovate');
            $scope.DailyUsageCount=[];
            // AJAX CALL FOR TOP DASHBOARDS USAGE
            $rootScope.query = {"size": 0,"aggs": {"group_by_dbname": {"date_histogram": {"field": "date","interval": "week"},"aggs": {"sum_of_dbcount": {"sum": {"field": "_dbcount"}}}}}};
            var data = averageRankingService(environment.apiUri+'/powerme/statistics/_search');
            data = JSON.parse(data);

            for (var i = 0; i < data.aggregations.group_by_dbname.buckets.length; i++) {
                var date1 = moment(data.aggregations.group_by_dbname.buckets[i].key_as_string,"YYYY-M-DD").format("YYYY,M,DD");
                date1 = date1.split(',');
                var month = date1[1] - 1;
                var dateFormat = Date.UTC(date1[0], month, date1[2]);
                $scope.DailyUsageCount.push([dateFormat,data.aggregations.group_by_dbname.buckets[i].sum_of_dbcount.value]);
            }

            angular
                .element('#ReportsChart')
                .highcharts({
                    chart: {
                        zoomType: 'x'

                    },

                    legend: {
                        enabled: false
                    },
                    title: {
                        text: 'Weekly Overall Dashboard Usage'
                    },
                    subtitle: {
                        text: document.ontouchstart === undefined ? 'Click and drag in the plot area to zoom in' : 'Pinch the chart to zoom in'
                    },

                    xAxis: {
                        type: 'datetime',

                        labels: {
                            autoRotation: false
                        }
                    },
                    yAxis: {
                        title: {
                            text: '# of Dashboard Hits'
                        },
                        min: 0,
                        labels: {
                            formatter: function() {
                                return this.value;
                            }
                        }
                    },

                    legend: {
                        enabled: false
                    },
                   series: [{
                        name: 'Daily Dashboard Usage',
                        data: $scope.DailyUsageCount
                    }]
                });

        }) // Controller Endpoint

// GRAPH 4 // // GRAPH 4 // // GRAPH 4 // // GRAPH 4 // // GRAPH 4 // // GRAPH 4

.controller('ForthChartCtrl',function($scope, $http, $rootScope, averageRankingService) {

        var app = angular.element('#minovate');
        $scope.UniqueUserNames=[];
        $scope.UniqueUserCount=[];
        // AJAX CALL FOR Top 10 Dashboards [Overall]

        $rootScope.query = {"size": 0,"aggs": {"fl": {"filter": {"bool": {"must_not": [{"terms": {"_dbname": ["NA","","Welcome","SSI-IB","1. Welcome"]}}]}},"aggs": {"db": {"terms": {"field": "_dbname","size": 10,"order": {"users.value":"desc"}},"aggs": {"users": {"cardinality": {"field": "_name","precision_threshold":40000}}}}}}}};
        var data = averageRankingService(environment.apiUri+'/powerme/statistics/_search');
        data = JSON.parse(data);
        /*
        var Application_Names = $rootScope.ApplicationNames;
        console.log(data.aggregations.fl.db.buckets.length);
        for (var i = 0; i < data.aggregations.fl.db.buckets.length; i++) {

        	var dashboard_id = data.aggregations.fl.db.buckets[i].key;
        	var dashboard_items = dashboard_id.split("/");
        	$scope.UniqueUserNames.push(dashboard_items[4]);
        	var ApplicationColor = $rootScope.Colors[Application_Names.indexOf(dashboard_items[1])];
        	ApplicationColor = ApplicationColor.toString();
        	$scope.UniqueUserCount.push({ y: data.aggregations.fl.db.buckets[i].users.value, color: ApplicationColor });

            }
      */
            for (var i = 0; i < data.aggregations.fl.db.buckets.length; i++) {

		        	$scope.UniqueUserNames.push(data.aggregations.fl.db.buckets[i].key);
		            $scope.UniqueUserCount.push(data.aggregations.fl.db.buckets[i].users.value);

                }


        angular
            .element('#ForthChart')
            .highcharts({
                chart: {
                    type: 'column',
                },
                title: {
                    text: 'Top 10 Dashboards by Number of Users'
                },
                legend: {

                    enabled: false
                },

                xAxis: {
                    categories: $scope.UniqueUserNames,
                    crosshair: true,
                    labels: {
                        autoRotation: false
                    },
                    offset: 0
                },
                yAxis: {
                    min: 0,
                    title: {
                        text: '# of Unique Users'
                    },
                    offset: 0
                },
                tooltip: {
                    headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                    pointFormat: '<tr><td style="color:{series.color};padding:0">Dashboard Hits: </td>' + '<td style="padding:0"><b>{point.y:.0f}</b></td></tr>',
                    footerFormat: '</table>',
                    shared: true,
                    useHTML: true
                },
                plotOptions: {
                    column: {
                        pointPadding: 0.2,
                        borderWidth: 0
                    }
                },
                series: [{
                    name: 'Dashboards',
                    data: $scope.UniqueUserCount

                }]
            });
    })
    
   
    /////////////////////////GRAPH 5  ///////////////////////////////////////////////////////////////////
   .controller('FifthChartCtrl',function($scope, $http, $rootScope, averageRankingService) {})
   
     /////////////////////////GRAPH 6  ///////////////////////////////////////////////////////////////////
   .controller('SixthChartCtrl',function($scope, $http, $rootScope, averageRankingService) {})
   
   
  