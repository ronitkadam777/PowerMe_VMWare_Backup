'use strict';

/**
 * @ngdoc function
 * @name powermeApp.controller:DaterangepickerCtrl
 * @description
 * # DaterangepickerCtrl
 * Controller of the powermeApp
 */



angular.module('powermeApp')
  .controller('DaterangepickerCtrl', function ($scope, $moment, $rootScope) {
   /* $scope.startDate = $moment().subtract(1, 'days').format('MMM D, YYYY');
    $scope.endDate = $moment().add(31, 'days').format('MMM D, YYYY');


    console.log($scope.startDate + " + " + $scope.endDate);
    $scope.rangeOptions = {
      ranges: {
        Today: [$moment(), $moment()],
        Yesterday: [$moment().subtract(1, 'days'), $moment().subtract(1, 'days')],
        'Last 7 Days': [$moment().subtract(6, 'days'), $moment()],
        'Last 30 Days': [$moment().subtract(29, 'days'), $moment()],
        'This Month': [$moment().startOf('month'), $moment().endOf('month')],
        'Last Month': [$moment().subtract(1, 'month').startOf('month'), $moment().subtract(1, 'month').endOf('month')]
      },
      opens: 'right',
      startDate: $moment().subtract(29, 'days'),
      endDate: $moment(),
      parentEl: '#content'
    };

   $scope.getDates=function(d1,d2){
  console.log(d1+"----"+d2);
   }
   angular.element('#daterange').on('cancel.daterangepicker', function(ev, picker) {
  //do something, like clearing an input
  $('#daterange').val('');
});*/
 angular.element('#reportrange span').html(moment().subtract(29, 'days').format('MMMM D, YYYY') + ' - ' + moment().format('MMMM D, YYYY'));

 angular.element('#reportrange').daterangepicker({
       format: 'MM/DD/YYYY',
       startDate: '07/01/2014',
       endDate: '9/30/2014',
       minDate: '01/01/2012',
       maxDate: '12/31/2015',
       //dateLimit: { days: 180 },
       showDropdowns: false,
       showWeekNumbers: false,
       timePicker: false,
       timePickerIncrement: 1,
       timePicker12Hour: true,
       ranges: {
          //'Today': [moment(), moment()],
          //'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
          //'Last 7 Days': [moment().subtract(6, 'days'), moment()],
          //'Last 30 Days': [moment().subtract(29, 'days'), moment()],
          //'This Month': [moment().startOf('month'), moment().endOf('month')],
          //'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
          //'Last Year': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]

         //'Q1-14': ['01/01/2014', '03/31/2014'],
         //
         //'Q2-14': ['04/01/2014', '06/30/2014'],
         //
         //'Q3-14': ['07/01/2014', '09/30/2014'],
         //
         //'Q4-14': ['10/01/2014', '31/31/2014'],

         'Q1-15': ['01/01/2015', '03/31/2015'],

         'Q2-15': ['04/01/2015', '06/30/2015'],

         'Q3-15': ['07/01/2015', '09/30/2015'],

         'Q4-15': ['10/01/2015', '12/31/2015']
       },
       opens: 'right',
       drops: 'down',
       buttonClasses: ['btn', 'btn-sm'],
       applyClass: 'btn-primary',
       cancelClass: 'btn-default',
       separator: ' to ',
       /*locale: {
           applyLabel: 'Submit',
           cancelLabel: 'Cancel',
           fromLabel: 'From',
           toLabel: 'To',
           customRangeLabel: 'Custom',
           daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr','Sa'],
           monthNames: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
           firstDay: 1
       }*/
   }, function(start, end, label) {
//        console.log(start.format('D-MMM-YYYY') , end.format('D-MMM-YYYY'), label);

       $rootScope.getDates(start.format('D-MMM-YYYY'),end.format('D-MMM-YYYY'),label);

       $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
   });


  });
