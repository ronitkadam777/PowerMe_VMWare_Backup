'use strict';

/**
 * @ngdoc function
 * @name powermeApp.controller:PagesSignupCtrl
 * @description
 * # PagesSignupCtrl
 * Controller of the powermeApp
 */
angular.module('powermeApp')
  .controller('SignupCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
