'use strict';

/**
 * @ngdoc function
 * @name powermeApp.controller:MailCtrl
 * @description
 * # MailCtrl
 * Controller of the powermeApp
 */
angular.module('powermeApp')
  .controller('MailCtrl', function ($scope) {

  });
