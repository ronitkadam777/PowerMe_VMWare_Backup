'use strict';

/**
 * @ngdoc function
 * @name powermeApp.controller:ButtonsiconsCtrl
 * @description
 * # ButtonsiconsCtrl
 * Controller of the powermeApp
 */
angular.module('powermeApp')
  .controller('ButtonsIconsCtrl', function ($scope) {
     $scope.page = {
      title: 'Buttons & Icons',
      subtitle: 'Place subtitle here...'
    };
  });
