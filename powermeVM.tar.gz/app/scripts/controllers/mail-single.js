'use strict';

/**
 * @ngdoc function
 * @name powermeApp.controller:MailSingleCtrl
 * @description
 * # MailSingleCtrl
 * Controller of the powermeApp
 */
angular.module('powermeApp')
  .controller('MailSingleCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
