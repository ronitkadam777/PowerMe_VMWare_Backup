'use strict';

/**
 * @ngdoc function
 * @name powermeApp.controller:TypographyCtrl
 * @description
 * # TypographyCtrl
 * Controller of the powermeApp
 */
angular.module('powermeApp')
  .controller('TypographyCtrl', function ($scope) {
    $scope.page = {
      title: 'Typography',
      subtitle: 'Place subtitle here...'
    };
  });
