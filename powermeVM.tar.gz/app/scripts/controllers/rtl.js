'use strict';

/**
 * @ngdoc function
 * @name powermeApp.controller:RtlCtrl
 * @description
 * # RtlCtrl
 * Controller of the powermeApp
 */
angular.module('powermeApp')
  .controller('RtlCtrl', function ($scope) {
    $scope.page = {
      title: 'RTL Layout',
      subtitle: 'Place subtitle here...'
    };
  });
