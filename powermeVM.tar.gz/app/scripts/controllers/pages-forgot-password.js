'use strict';

/**
 * @ngdoc function
 * @name powermeApp.controller:PagesForgotPasswordCtrl
 * @description
 * # PagesForgotPasswordCtrl
 * Controller of the powermeApp
 */
angular.module('powermeApp')
  .controller('ForgotPasswordCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
