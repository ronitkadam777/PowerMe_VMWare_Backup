'use strict';
/**
 *
 */
angular.module('powermeApp')
  .controller('personaCtrl',
  ['$scope', '$rootScope', 'personas', 'users', 'ngTableParams', 'Users', '$filter',
   function ($scope, $rootScope, personas, users, ngTableParams, Users, $filter) {
     $scope.options = {
       tableData: users.hits.hits
     }
     $scope.tableParams = new ngTableParams({
       page: 1,            // show first page
       count: 10           // count per page
     }, {
       total: $scope.options.tableData.length, // length of data
       counts:[],
       getData: function ($defer, params) {
         $defer.resolve($scope.options.tableData.slice((params.page() - 1) * params.count(),
                                                       params.page() * params.count()));
       }
     });
     $scope.sort = function(keyname){
         $scope.sortKey = keyname;   //set the sortKey to the param passed
         $scope.reverse = !$scope.reverse; //if true make it false and vice versa
     }
     
     $scope.addUser = function (user_name, roles) {
       $scope.saveUser({
         user_name: user_name,
         roles: roles,
         add_desc: true,
         remove_desc: false
       }, true);
     }

     $scope.saveUser = function (user, isNew) {
       var newUser = new Users(user);

       newUser.$save(function (data, headers) {
         console.log("Result of User Save : ", data);
         if (isNew) {
           data._source = user;
           $scope.options.tableData.push(data);
           $scope.tableParams.reload();
         }
       }, function (err) {
         console.error(err);
       });

     }
   }]);
