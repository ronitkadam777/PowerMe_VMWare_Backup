'use strict';

/**
 * @ngdoc function
 * @name powermeApp.controller:ShopSingleInvoiceCtrl
 * @description
 * # ShopSingleInvoiceCtrl
 * Controller of the powermeApp
 */
angular.module('powermeApp')
  .controller('SingleInvoiceCtrl', function ($scope) {
    $scope.page = {
      title: 'Single Invoice',
      subtitle: 'Place subtitle here...'
    };
  });
