var environment = {
    'apiUri' : 'http://52.34.51.160:9200',
    'authenticationUrl' : 'http://52.34.51.160:9999'	
};
